#include <string>
#include <vector>
#include <iostream>

using namespace std;

#ifndef insertion_sort_h
#define insertion_sort_h

template <class Comparable>
void insertionSort (vector <Comparable> & a)
{
    int j;
               // loop over the passes
    for (int p = 1;  p < a.size(); p++)
    {
        Comparable tmp = a[p];
                            // loop over the elements
        for (j = p; j > 0 &&  tmp.fullname < a[j-1].fullname; j--)
            a[j] = a[j-1];
        a[j] = tmp;
    }
}

#endif /* insertion_sort_h */
