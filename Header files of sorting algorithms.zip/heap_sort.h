#include <string>
#include <vector>
#include <iostream>

using namespace std;

#ifndef heap_sort_h
#define heap_sort_h

template <class Comparable>
void Swap( Comparable & obj1, Comparable & obj2 )
{
     Comparable tmp = obj1;
     obj1 = obj2;
     obj2 = tmp;
}

template <class Comparable>
void heapsort(vector<Comparable> & a)
{
    // buildHeap
    for (int i = a.size()/2; i >=0; i--)
        percDown(a, i, a.size());

    // sort
    for (int j = a.size()-1; j >0; j--)
    {
           Swap(a[0], a[j]);    // swap max to the last pos.
          percDown(a, 0, j); // re-form the heap
    }
}
 
inline int leftChild( int i )
{
    return 2*i+1;
}

template <class Comparable>  // for deleteMax
// a is the array, i is the position to percolate down from
// n is the logical size of the array
void percDown( vector<Comparable> & a, int i, int n )
{
    int child;
      Comparable tmp;

      for (tmp=a[i] ; leftChild(i) < n; i = child )
      {
            child = leftChild(i);
            if ( child != n-1 && a[child].fullname < a[child+1].fullname )
                 child++;
                 if ( a[child ].fullname > tmp.fullname)
                      a[i] = a[child];
                 else
                      break;
       }
       a[ i ] = tmp;
}
 
#endif /* heap_sort_h */
