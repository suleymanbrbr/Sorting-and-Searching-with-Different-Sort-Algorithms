#include <string>
#include <vector>
#include <iostream>

using namespace std;

#ifndef quick_sort_h
#define quick_sort_h

/**
 * Quicksort algorithm (driver).
*/
template <class Comparable>
void quicksort( vector<Comparable> & a )
{
      quicksort( a, 0, a.size( ) - 1 );
}

/**
* Standard swap
*/
template <class Comparable>
void SWAP( Comparable & obj1, Comparable & obj2 )
{
     Comparable tmp = obj1;
     obj1 = obj2;
     obj2 = tmp;
}

/** Return median of left, center, and right.
    *   Order these and hide the pivot.
  */
 template <class Comparable>
 const Comparable & median3( vector<Comparable> & a,
                                    int left, int right )
 {
       int center = ( left + right ) / 2;
       if ( a[center].fullname < a[left].fullname )
           SWAP( a[ left ], a[ center ] );
       if ( a[ right ].fullname < a[ left ].fullname )
           SWAP( a[ left ], a[ right ] );
       if ( a[ right ].fullname < a[ center ].fullname )
           SWAP( a[ center ], a[ right ] );

       // Place pivot at position right - 1
     SWAP( a[ center ], a[ right - 1 ] );
       return a[ right - 1 ];
 }

/**
   * Internal quicksort method that makes recursive calls.
   * Uses median-of-three partitioning and a cutoff of 10.
   * a is an array of Comparable items.
   * left is the left-most index of the subarray.
   * right is the right-most index of the subarray.
   */
  template <class Comparable>
  void quicksort( vector<Comparable> & a, int left, int right )
  {
        if ( left + 10 <= right )
        {
             Comparable pivot = median3( a, left, right );
        // Begin partitioning
            
       int i = left, j = right - 1;
       for ( ; ; )
       {
           while ( a[ ++i ].fullname < pivot.fullname ) { }

           while ( pivot.fullname < a[--j].fullname ) { }

           if ( i < j )
               SWAP( a[ i ], a[ j ] );
           else
                 break;
       }                
        
            SWAP( a[ i ], a[ right - 1 ] );   // Restore pivot
            
        quicksort( a, left, i - 1 );       // Sort small elements
        quicksort( a, i + 1, right );    // Sort large elements
       }
       else  // Do an insertion sort on the subarray
            insertionSort( a, left, right );
   }

/**
   * Internal insertion sort routine for subarrays
   * that is used by quicksort.
   * a is an array of Comparable items.
   * left is the left-most index of the subarray.
   * right is the right-most index of the subarray.
   */
  template <class Comparable>
  void insertionSort( vector<Comparable> & a, int left, int right )
  {
       for ( int p = left + 1; p <= right; p++ )
       {
            Comparable tmp = a[ p ];
            int j;

            for ( j = p; j > left && tmp.fullname < a[j - 1].fullname; j-- )
                 a[ j ] = a[ j - 1 ];
            a[ j ] = tmp;
      }
  }

#endif /* quick_sort_h */
