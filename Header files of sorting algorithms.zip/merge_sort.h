#include <string>
#include <vector>
#include <iostream>

using namespace std;

#ifndef merge_sort_h
#define merge_sort_h

/**
* Mergesort algorithm (driver).
*/
template <class Comparable>
void mergeSort( vector<Comparable> & a )
{
     mergeSort( a, 0, a.size( ) - 1 );
}

/**
* Internal method that makes recursive calls.
* a is an array of Comparable items.
* tmpArray is an array to place the merged result.
* left is the left-most index of the subarray.
* right is the right-most index of the subarray.
*/
template <class Comparable>
void mergeSort( vector<Comparable> & a, int left, int right )
{
     if ( left < right )
     {
        int mid = left + (right - left) / 2;
        mergeSort(a, left, mid);
        mergeSort(a, mid + 1, right);
        merge(a, left, mid, right);
     }
}

/**
* Internal method that merges two sorted halves of a subarray.
* a is an array of Comparable items.
* tmpArray is an array to place the merged result.
* leftPos is the left-most index of the subarray.
* rightPos is the index of the start of the second half.
* rightEnd is the right-most index of the subarray.
*/

template <typename Comparable>
void merge(vector<Comparable>& a, int left, int mid, int right) {
    int leftIndex = left;
    int rightIndex = mid + 1;

    while (leftIndex <= mid && rightIndex <= right) {
        if (a[leftIndex].fullname > a[rightIndex].fullname) {
            Comparable temp = move(a[rightIndex]);

            for (int i = rightIndex - 1; i >= leftIndex; --i) {
                a[i + 1] = move(a[i]);
            }

            a[leftIndex] = move(temp);
            ++mid;
            ++rightIndex;
        }
        ++leftIndex;
    }
}

#endif /* merge_sort_h */
