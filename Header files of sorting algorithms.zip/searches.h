#include <string>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

#ifndef searches_h
#define searches_h

// Sequential search function
template <typename Compare>
void sequentialSearch(const vector<Compare>& vec, const string& key, vector<Compare>& founded) {
    
    
    for (int i = 0; i < vec.size(); ++i) {
        if (key.length() <= vec[i].fullname.length() && vec[i].fullname.substr(0, key.length()) == key) {
            founded.push_back(vec[i]);
        }
    }
}

// Binary search function (assuming the vector is sorted)
template <typename Compare>
int binarySearch(const vector<Compare>& vec, const string& key, vector<Compare>& founded) {
    
    int left = 0;
    int right = vec.size() - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;
        
        if (key.length() <= vec[mid].fullname.length() && vec[mid].fullname.substr(0, key.length()) == key) {
            founded.push_back(vec[mid]);
            
            int idx = mid-1;
            while (idx >= 0 && key.length() <= vec[idx].fullname.length() && vec[idx].fullname.substr(0, key.length()) == key) {
                founded.push_back(vec[idx]);
                idx--;
            }
            // Search for the rightmost occurrence
            idx = mid + 1;
            while (idx < vec.size() && key.length() <= vec[idx].fullname.length() && vec[idx].fullname.substr(0, key.length()) == key) {
                founded.push_back(vec[idx]);
                idx++;
            }
            return mid; // Return the index of the found element
            
        } else if (vec[mid].fullname < key) {
            left = mid + 1; // Search in the right half
        } else {
            right = mid - 1; // Search in the left half
        }
    }

    return -1; // Return -1 if key is not found
}

#endif /* searches_h */
